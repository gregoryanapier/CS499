package contactservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ContactRepository {

    public ContactRepository() {
        createTable();
    }

    private void createTable() {
        String sql = "CREATE TABLE IF NOT EXISTS contacts (" +
                "contactId TEXT PRIMARY KEY, " +
                "firstName TEXT, " +
                "lastName TEXT, " +
                "phone TEXT, " +
                "address TEXT" +
                ")";

        try (Connection conn = DatabaseManager.connect();
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to create contacts table", e);
        }
    }

    public void add(Contact contact) {
        String sql = "INSERT INTO contacts (contactId, firstName, lastName, phone, address) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, contact.getContactId());
            pstmt.setString(2, contact.getFirstName());
            pstmt.setString(3, contact.getLastName());
            pstmt.setString(4, contact.getPhone());
            pstmt.setString(5, contact.getAddress());

            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalArgumentException("Contact already exists");
        }
    }

    public Contact findById(String contactId) {
        String sql = "SELECT * FROM contacts WHERE contactId = ?";

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, contactId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return new Contact(
                        rs.getString("contactId"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("phone"),
                        rs.getString("address")
                );
            } else {
                throw new IllegalArgumentException("Contact ID not found");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Failed to find contact", e);
        }
    }

    public void delete(String contactId) {
        String sql = "DELETE FROM contacts WHERE contactId = ?";

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, contactId);
            int rowsDeleted = pstmt.executeUpdate();

            if (rowsDeleted == 0) {
                throw new IllegalArgumentException("Contact ID not found");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Failed to delete contact", e);
        }
    }

    public void updateFirstName(String contactId, String firstName) {
        String sql = "UPDATE contacts SET firstName = ? WHERE contactId = ?";

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, firstName);
            pstmt.setString(2, contactId);
            int rowsUpdated = pstmt.executeUpdate();

            if (rowsUpdated == 0) {
                throw new IllegalArgumentException("Contact ID not found");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Failed to update first name", e);
        }
    }

    public void updateLastName(String contactId, String lastName) {
        String sql = "UPDATE contacts SET lastName = ? WHERE contactId = ?";

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, lastName);
            pstmt.setString(2, contactId);
            int rowsUpdated = pstmt.executeUpdate();

            if (rowsUpdated == 0) {
                throw new IllegalArgumentException("Contact ID not found");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Failed to update last name", e);
        }
    }

    public void updatePhone(String contactId, String phone) {
        String sql = "UPDATE contacts SET phone = ? WHERE contactId = ?";

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, phone);
            pstmt.setString(2, contactId);
            int rowsUpdated = pstmt.executeUpdate();

            if (rowsUpdated == 0) {
                throw new IllegalArgumentException("Contact ID not found");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Failed to update phone", e);
        }
    }

    public void updateAddress(String contactId, String address) {
        String sql = "UPDATE contacts SET address = ? WHERE contactId = ?";

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, address);
            pstmt.setString(2, contactId);
            int rowsUpdated = pstmt.executeUpdate();

            if (rowsUpdated == 0) {
                throw new IllegalArgumentException("Contact ID not found");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Failed to update address", e);
        }
    }

    public List<Contact> searchByFirstName(String firstName) {
        List<Contact> results = new ArrayList<>();
        String sql = "SELECT * FROM contacts WHERE firstName = ?";

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, firstName);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                results.add(new Contact(
                        rs.getString("contactId"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("phone"),
                        rs.getString("address")
                ));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Failed to search by first name", e);
        }

        return results;
    }

    public List<Contact> searchByLastName(String lastName) {
        List<Contact> results = new ArrayList<>();
        String sql = "SELECT * FROM contacts WHERE lastName = ?";

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, lastName);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                results.add(new Contact(
                        rs.getString("contactId"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("phone"),
                        rs.getString("address")
                ));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Failed to search by last name", e);
        }

        return results;
    }

    public void clearAll() {
        String sql = "DELETE FROM contacts";

        try (Connection conn = DatabaseManager.connect();
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to clear contacts table", e);
        }
    }
}