package contactservice;

import java.util.List;

public class ContactService {

    private final ContactRepository repository;

    public ContactService() {
        this.repository = new ContactRepository();
    }

    public void addContact(Contact contact) {
        repository.add(contact);
    }

    public void deleteContact(String contactId) {
        repository.delete(contactId);
    }

    public void updateFirstName(String contactId, String firstName) {
        repository.updateFirstName(contactId, firstName);
    }

    public void updateLastName(String contactId, String lastName) {
        repository.updateLastName(contactId, lastName);
    }

    public void updatePhone(String contactId, String phone) {
        repository.updatePhone(contactId, phone);
    }

    public void updateAddress(String contactId, String address) {
        repository.updateAddress(contactId, address);
    }

    public List<Contact> searchByFirstName(String firstName) {
        return repository.searchByFirstName(firstName);
    }

    public List<Contact> searchByLastName(String lastName) {
        return repository.searchByLastName(lastName);
    }

    public void clearAllContacts() {
        repository.clearAll();
    }
}