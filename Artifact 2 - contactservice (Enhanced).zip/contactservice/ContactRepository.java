package contactservice;

import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

public class ContactRepository {
    private final Map<String, Contact> contactMap = new HashMap<>();

    public void add(Contact contact) {
        if (contact == null || contactMap.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact already exists or is null");
        }
        contactMap.put(contact.getContactId(), contact);
    }

    public void delete(String contactId) {
        if (!contactMap.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contactMap.remove(contactId);
    }

    public Contact findById(String contactId) {
        Contact contact = contactMap.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        return contact;
    }

    public List<Contact> searchByFirstName(String firstName) {
        List<Contact> results = new ArrayList<>();

        for (Contact contact : contactMap.values()) {
            if (contact.getFirstName().equalsIgnoreCase(firstName)) {
                results.add(contact);
            }
        }

        return results;
    }

    public List<Contact> searchByLastName(String lastName) {
        List<Contact> results = new ArrayList<>();

        for (Contact contact : contactMap.values()) {
            if (contact.getLastName().equalsIgnoreCase(lastName)) {
                results.add(contact);
            }
        }

        return results;
    }
}