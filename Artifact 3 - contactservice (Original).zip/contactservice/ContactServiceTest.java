package contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService service;
    private Contact contact;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
        contact = new Contact("001", "Jillian", "Murphy", "1234567890", "123 Courier Ct");
        service.addContact(contact);
    }

    @Test
    public void testAddValidContact() {
        Contact newContact = new Contact("002", "Jane", "Smith", "0987654321", "456 Elm St");
        service.addContact(newContact);
        assertDoesNotThrow(() -> service.updateFirstName("002", "Janet"));
    }

    @Test
    public void testAddDuplicateContactId() {
        Contact duplicate = new Contact("001", "Jake", "Hill", "1112223333", "999 Maple Ave");
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(duplicate);
        });
    }

    @Test
    public void testDeleteContact() {
        service.deleteContact("001");
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateLastName("001", "Smith");
        });
    }

    @Test
    public void testUpdateFirstName() {
        service.updateFirstName("001", "Mike");
        assertEquals("Mike", contact.getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        service.updateLastName("001", "Johnson");
        assertEquals("Johnson", contact.getLastName());
    }

    @Test
    public void testUpdatePhone() {
        service.updatePhone("001", "1112223333");
        assertEquals("1112223333", contact.getPhone());
    }

    @Test
    public void testUpdateAddress() {
        service.updateAddress("001", "999 Oak Ln");
        assertEquals("999 Oak Ln", contact.getAddress());
    }

    @Test
    public void testUpdateNonExistentContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("999", "Ghost");
        });
    }

    @Test
    public void testDeleteNonExistentContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("999");
        });
    }
}
