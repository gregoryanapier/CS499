package contactservice;

import java.util.HashMap;
import java.util.Map;

public class ContactRepository {
    private final Map<String, Contact> contactMap = new HashMap<>();

    public void add(Contact contact) {
        if (contact == null || contactMap.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact already exists or is null");
        }
        contactMap.put(contact.getContactId(), contact);
    }

    public void delete(String contactId) {
        if (!contactMap.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contactMap.remove(contactId);
    }

    public Contact findById(String contactId) {
        Contact contact = contactMap.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        return contact;
    }
}