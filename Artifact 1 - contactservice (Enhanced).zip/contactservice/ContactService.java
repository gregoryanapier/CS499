package contactservice;

public class ContactService {

    private final ContactRepository repository;

    public ContactService() {
        this.repository = new ContactRepository();
    }

    // Add a new contact
    public void addContact(Contact contact) {
        repository.add(contact);
    }

    // Delete a contact by ID
    public void deleteContact(String contactId) {
        repository.delete(contactId);
    }

    // Update first name
    public void updateFirstName(String contactId, String firstName) {
        Contact contact = repository.findById(contactId);
        contact.setFirstName(firstName);
    }

    // Update last name
    public void updateLastName(String contactId, String lastName) {
        Contact contact = repository.findById(contactId);
        contact.setLastName(lastName);
    }

    // Update phone number
    public void updatePhone(String contactId, String phone) {
        Contact contact = repository.findById(contactId);
        contact.setPhone(phone);
    }

    // Update address
    public void updateAddress(String contactId, String address) {
        Contact contact = repository.findById(contactId);
        contact.setAddress(address);
    }
}